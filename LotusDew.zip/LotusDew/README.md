# LotusDew
Implementation of trading algorithm, explained by LotusDew employees as part of their hiring process.
